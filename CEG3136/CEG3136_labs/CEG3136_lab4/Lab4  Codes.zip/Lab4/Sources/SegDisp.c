/*--------------------------------------------
File: SegDisp.c
Description:  Segment Display Module
---------------------------------------------*/

#include <stdtypes.h>
#include "mc9s12dg256.h" 
#include "SegDisp.h"
#define delaydisp 3750
#define BIT1 0b00000010 // set bit for channel 1

//prototype
void assignValueToPortP(byte);
void printPortB(char);
void interrupt VectorNumber_Vtimch1 disp_isr(void);
char characters[4];
byte enablesCodes []= {0b00001110, 0b00001101, 0b00001011, 0b00000111};  // display numbers
static byte num = 0;

/*---------------------------------------------
Function: initDisp
Description: initializes hardware for the 
             7-segment displays.
-----------------------------------------------*/
void initDisp(void) 
{
	// Complete this function
	DDRB = 0xff; //output
	DDRP = 0xff; //output
	clearDisp();
	TIOS |= BIT1; //Input for channel 1
	TIE |= BIT1; //enable interrupts
	TC1 = TCNT + delaydisp;
}

/*---------------------------------------------
Function: clearDisp
Description: Clears all displays.
-----------------------------------------------*/
void clearDisp(void) 
{
	//Delete saved characters
	characters[0] = '\0'; //null char
	characters[1] = '\0';
	characters[2] = '\0';
	characters[3] = '\0';
	// Complete this function
	PTP = 0x00;
	PORTB = 0x3F;
}

/*---------------------------------------------
Function: setCharDisplay
Description: Receives an ASCII character (ch)
             and translates
             it to the corresponding code to 
             display on 7-segment display.  Code
             is stored in appropriate element of
             codes for identified display (dispNum).
-----------------------------------------------*/
void setCharDisplay(char ch, byte dispNum) 
{
	
   characters[dispNum] = ch;

   if(dispNum == 0) { // first from left
    PTP = 0x0E; // 0000 1110
  } else if(dispNum == 1) { //second from left
    PTP = 0x0D; // 0000 1101
  } else if(dispNum == 2) { //third from left
    PTP = 0x0B; // 0000 1011
  } else { //rightmost
    PTP = 0x07; // 0000 0111
  }	
	
   if(ch == '0') 
  {
    PORTB = 0x3F;
  } else if(ch == '1') {
    PORTB = 0x06;
  } else if(ch == '2') {
    PORTB = 0x5B;
  } else if(ch == '3') {
    PORTB = 0x4F;
  } else if(ch == '4') {
    PORTB = 0x66;
  } else if(ch == '5') {
    PORTB = 0x6D;
  } else if(ch == '6') {
    PORTB = 0x7D;
  } else if(ch == '7') {
    PORTB = 0x07;
  } else if(ch == '8') {
    PORTB = 0x7F;
  } else if(ch == '9'){
    PORTB = 0x6F; //67?
  }else if(ch == ' '){
    PORTB = 0x00;
  }else if(ch == 'A'){
    PORTB = 0x77; //0111 0111
  }else if(ch == 'b'){
    PORTB = 0x7C; //0111 1100
  }else if(ch == 'C'){
    PORTB = 0x39; //0011 1001
  }else if(ch == 'd'){
    PORTB = 0x5E; //0101 1110
  }else if(ch == '#'){
    PORTB = 0x70; //0111 0000
  }else if(ch == '*'){
    PORTB = 0x46; //0100 0110
  }else  {
	PORTB = 0x00;	
  }
}

/*----------------------------------------------------
Interrupt: tc0_isr
Description: This service routine updates the display.
-------------------------------------------------------*/
void interrupt VectorNumber_Vtimch1 disp_isr(void)
{
	byte enable;
	PORTB = characters[num]; // pass character to port b
	enable = PTP;
	enable &= 0xF0;
	setCharDisplay(characters[num], num);
	PTP = enable | enablesCodes [num++];
	num = num%4;
  	TC1 = TC1 + delaydisp;
}
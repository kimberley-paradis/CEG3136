/*-----------------------------
* File: lcdDisp.h
* Description: header file for LCD module
*-------------------------------*/

// Prototypes - Entry points

void initLCD(void);
void printLCDStr(char *, byte);

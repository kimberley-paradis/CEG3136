/*---------------------------------------------
 File: Tutorial6Option.c
 Description:
    This file contains code to demonstrate the use of interrupts.
    A push button switchis used to invoke an interrupt.  Each time 
    it is pressed an asterisk is printed on the terminal. When it has 
    been pressed 10 times a message is displayed on the terminal.
---------------------------------------------------*/
#include <stdio.h>
#include <stdtypes.h>
#include "mc9s12dg256.h"
static byte counter, astrsk;
static char[] message = "Interrupts work";
/*----------------------------------------------------
Function: main
---------------------------------------------------*/
void main(void)
{
	// Setup interrups
	INTCR |= 0b10000000;    // IRQE = 1, IRQ edge-sensitive
	INTCR |= 0b01000000;    // IRQEN = 1, Activate IRQ
	asm cli;		// Enable global interrupts
	// Initialize counter
	counter = 10;
	astrsk = 0;	
        set_lcd_addr(0);
	while (counter > 0) // loop until receive 10 interrupts
	{
		// Print asterisk if we have received an interrupt
		if astrsk > 0
		{
			data8('*');
			astrsk--;
		}
	}	
	printLCDStr(message, 1);  // print message
}
/*---------------------------------------------
Interrupt: pb_isr
Description: Receive an IRQ when push button is pressed.
---------------------------------------------------*/
void interrupt VectorNumber_Virq pb_isr(void) 
{
       counter--;
       astrsk++;
}
